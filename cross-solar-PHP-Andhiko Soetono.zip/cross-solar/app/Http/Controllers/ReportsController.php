<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Panel;
use App\Models\OneHourElectricity;
use DB;

class ReportsController extends Controller
{
        //view panel KWh on days
    public function reportPanel($id){

             $reports = DB::select('SELECT SUM(kilowatts) as total, panel_id, hour FROM one_hour_electricities WHERE panel_id='.$id.' group by DATE(hour)');
            
             
       return view('reports')->with('reports', $reports);
    }
}
