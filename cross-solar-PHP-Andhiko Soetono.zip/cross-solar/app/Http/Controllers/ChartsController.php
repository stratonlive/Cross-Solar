<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Panel;
use App\Models\OneHourElectricity;
use DB;
use Charts;
//use ConsoleTVs\Charts\Facades\Charts;


class ChartsController extends Controller
{
 
    
       public function panelWatt($id){

             $charts = DB::select('SELECT SUM(kilowatts) as total, panel_id, hour FROM one_hour_electricities WHERE panel_id='.$id.' group by DATE(hour)');
            
      
       return view('charts')->with('panel', $charts);
    }

      
    }

