<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Panel;

class MessagesController extends Controller
{
public function submit(Request $request){
    $this->validate($request, [
        'serial' => 'required',
        'latitude' => 'required',
        'longitude' => 'required'
     ]);
    
    //Create new panel
    $panel=new Panel;
    $panel->serial=$request->input('serial');
    $panel->latitude=$request->input('latitude');
    $panel->longitude=$request->input('longitude');
    //Save the panel
    $panel->save();
    
    //Redirect
    return redirect('/')->with('success', 'panel sent');
    }
    
    //view panels
    public function getPanel(){
        $panels=Panel::all();
        
        return view('panels')->with('panels', $panels);
    }
    

}
