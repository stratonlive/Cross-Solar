<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\OneHourElectricity;
use Illuminate\Support\Facades\DB;

class WattController extends Controller
{
  public function submit(Request $request){
    $this->validate($request, [
        'panel_id' => 'required',
        //'hour' => 'use current date on mysql database',
        'kilowatts' => 'required'
     ]);
    
    //Create new Kwh
    $watt=new OneHourElectricity;
    $watt->panel_id=$request->input('panel_id');
    
    $watt->kilowatts=$request->input('kilowatts');
    //Save the Kwh
    $watt->save();
    
    //Redirect
    return redirect('/')->with('success', 'production sent');
    }
    
    //view Kwh
    
    public function getWatt(){
        $report = DB::select('SELECT SUM(kilowatts) as total, panel_id, hour FROM one_hour_electricities group by DATE(hour)');
        
        return view('report')->with('report', $report);
    }
     
}
