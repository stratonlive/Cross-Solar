<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Panel;
use App\Models\OneHourElectricity;
use DB;
use Charts;


class ChartController extends Controller
{
   
         //view Kwh on days
    public function dayWatt(){
           
             $chart = DB::select('SELECT SUM(kilowatts) as total, MIN(kilowatts) as min, MAX(kilowatts) as max, AVG(kilowatts) as average, panel_id, hour FROM one_hour_electricities group by panel_id, DATE(hour)');
             
       return view('chart')->with('chart', $chart);
    }

    }

