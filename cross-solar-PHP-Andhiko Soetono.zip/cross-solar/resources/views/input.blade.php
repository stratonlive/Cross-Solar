@extends('layouts.app')

@section('content')
<h1>Input Panel</h1>
{!! Form::open(['url' => 'input/submit']) !!}
<div class="form-group">
    {{ Form::label('serial', 'serial') }}
    {{ Form::text('serial', '', ['class' => 'form-control', 'placeholder' =>'Enter Serial'] ) }}
</div>
<div class="form-group">
    {{ Form::label('latitude', 'latitude') }}
    {{ Form::text('latitude', '', ['class' => 'form-control', 'placeholder' =>'Enter Latitude']) }}
</div>
<div class="form-group">
    {{ Form::label('longitude', 'longitude') }}
    {{ Form::text('longitude', '', ['class' => 'form-control', 'placeholder' =>'Enter Longitude']) }}
</div>

<div>
    {{ Form::submit('Submit', ['class' => 'btn btn-primary']) }}
</div>
{!! Form::close() !!}
@endsection

@section('sidebar')
    @parent
    <p>The Solar Technology</p>

@endsection
