@extends('layouts.app')

@section('content')
<h1>About</h1>
<p>
    We are Energy Clean Power Plant.
    
</p>
@endsection

@section('sidebar')
   @parent
    <p>This is the history of our Company</p>

@endsection