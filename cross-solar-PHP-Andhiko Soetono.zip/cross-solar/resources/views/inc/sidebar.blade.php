@section('sidebar')
<div class="sidebar">
    <h3>Latest News</h3>
    
</div>
@show