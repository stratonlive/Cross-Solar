<div class="jumbotron text-center">
    <div class="container">
        <h1>Welcome to Cross Solar</h1>
        <p class="lead">Welcome to Cross Solar, we provide clean energy.</p>
    </div>  
</div>