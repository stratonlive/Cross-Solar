@extends('layouts.app')

@section('content')
<h1>Daily Kwh Reports</h1>

 @if(count($chart)>0)
   @foreach($chart as $panel)
<ul class="list-group">
    <li class="list-group-item"> <a class="button" href="charts/{{$panel->panel_id}}">Panel ID : {{$panel->panel_id}}</a></li>
    <li class="list-group-item">Hour : {{date('M j, Y H:i', strtotime($panel->hour))}}</li>
    <li class="list-group-item">Kwh : {{$panel->total}} Kwh</li>
    <li class="list-group-item">Min Kwh : {{$panel->min}} Kwh</li>
    <li class="list-group-item">Max Kwh : {{$panel->max}} Kwh</li>
    <li class="list-group-item">Average Kwh : {{$panel->average}} Kwh</li>
</ul> <br>
    @endforeach
    @endif
    
@endsection

@section('sidebar')
    @parent
    <p>Electricity</p>

@endsection