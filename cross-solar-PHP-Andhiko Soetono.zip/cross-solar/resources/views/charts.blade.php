@extends('layouts.app')

@section('content')
<h1>Kwh Chart Reports</h1>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable(      
        [
        ['Date and Time', 'Total KWh'],
        @foreach($panel as $panels)['{{$panels->hour}}','{{$panels->total}}'],
        @endforeach
        ]);

        var options = {
          chart: {
            title: 'Panel Daily Performance',
            subtitle: 'Total KWh Each Day',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
    
   <div id="barchart_material" style="width: 600px; height: 400px;"></div>
   

@endsection

@section('sidebar')
    @parent
    <p>Electricity</p>

@endsection