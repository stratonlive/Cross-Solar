@extends('layouts.app')

@section('content')
<h1>Kwh Input Reports</h1>

 @if(count($report)>0)
   @foreach($report as $watt)
<ul class="list-group">
    <li class="list-group-item"> <a class="button" href="reports/{{$watt->panel_id}}">Panel ID : {{$watt->panel_id}}</a></li>
    <li class="list-group-item">Hour : {{date('M j, Y H:i', strtotime($watt->hour))}}</li>
    <li class="list-group-item">Kwh : {{$watt->total}} Kwh</li>
</ul> <br>
    @endforeach
    @endif
    
@endsection

@section('sidebar')
    @parent
    <p>Electricity</p>

@endsection