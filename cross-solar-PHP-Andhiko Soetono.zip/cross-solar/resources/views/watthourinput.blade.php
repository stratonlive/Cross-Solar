@extends('layouts.app')

@section('content')
<h1>Input Watt Hour</h1>
{!! Form::open(['url' => 'watthourinput/submit']) !!}
<div class="form-group">
    {{ Form::label('panel_id', 'panel_id') }}
    {{ Form::text('panel_id', '', ['class' => 'form-control', 'placeholder' =>'Enter Panel ID'] ) }}
</div>

<div class="form-group">
    {{ Form::label('kilowatts', 'kilowatts') }}
    {{ Form::text('kilowatts', '', ['class' => 'form-control', 'placeholder' =>'Enter Kilowatt']) }}
</div>

<div>
    {{ Form::submit('Submit', ['class' => 'btn btn-primary']) }}
</div>
{!! Form::close() !!}
@endsection

@section('sidebar')
    @parent
    <p>Electricity Technology</p>

@endsection
