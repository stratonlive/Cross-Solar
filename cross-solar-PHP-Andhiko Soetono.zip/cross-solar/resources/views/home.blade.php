@extends('layouts.app')

@section('content')
<h1>Home</h1>
<p>
    The Future of Technology is in our hand.
    
</p>
@endsection

@section('sidebar')
    @parent
    <p>New Technology Development</p>

@endsection