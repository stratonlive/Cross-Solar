@extends('layouts.app')

@section('content')
<h1>Panels List</h1>

   @if(count($panels)>0)
   @foreach($panels as $panel)
<ul class="list-group">
    <li class="list-group-item">Panel ID : {{$panel->id}}</li>
    <li class="list-group-item">Serial: {{$panel->serial}}</li>
    <li class="list-group-item">Latitude: {{$panel->latitude}}</li>
    <li class="list-group-item">Longitude: {{$panel->longitude}}</li>
</ul> <br>
    @endforeach
    @endif
@endsection

@section('sidebar')
    @parent
    <p>Solar Technology</p>

@endsection