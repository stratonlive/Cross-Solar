@extends('layouts.app')

@section('content')
<h1>Daily Panel Kwh Reports</h1>

 @if(count($reports)>0)
   @foreach($reports as $watts)
<ul class="list-group">
    <li class="list-group-item">Panel ID : {{$watts->panel_id}}</a></li>
    <li class="list-group-item">Hour : {{date('M j, Y H:i', strtotime($watts->hour))}}</li>
    <li class="list-group-item">Kwh : {{$watts->total}} Kwh</li>
</ul> <br>
    @endforeach
    @endif
    
@endsection

@section('sidebar')
    @parent
    <p>Electricity</p>

@endsection