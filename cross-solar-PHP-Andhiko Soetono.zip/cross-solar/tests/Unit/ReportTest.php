<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Carbon\Carbon;

use Illuminate\Http\Request;
use App\Models\OneHourElectricity;
use App\Models\Panel;
use App\Http\Controllers\WattController;

class ReportTest extends TestCase
{
     use RefreshDatabase;
     /**
     * A basic test example.
     *
     * @return void
     */
    public function testExample()
    {
        $this->assertTrue(true);
    }

        public function testAssert()
    {
        $this->get('/')->assertSee('Welcome');
        $this->get('/about')->assertSee('Energy');
    }
    
    public function testKwh()
    {
         $first= factory(App\Models\OneHourElectricity::class)->make();
         $post=WattController::getWatt();
        $this->assertEqual([
            [
               "panel_id"->$first->panel_id,
                "hour"->$first->hour,
                "total"->$first->kilowatts
                ]
            ], $post);
    }
    
}
