<?php

use Illuminate\Database\Seeder;

class PanelsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Models\Panel::class, 30)->create();

        factory(App\Models\OneHourElectricity::class, 30)->create();
        
    }
}
