<?php $__env->startSection('content'); ?>
<h1>Input Watt Hour</h1>
<?php echo Form::open(['url' => 'watthourinput/submit']); ?>

<div class="form-group">
    <?php echo e(Form::label('panel_id', 'panel_id')); ?>

    <?php echo e(Form::text('panel_id', '', ['class' => 'form-control', 'placeholder' =>'Enter Panel ID'] )); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('kilowatts', 'kilowatts')); ?>

    <?php echo e(Form::text('kilowatts', '', ['class' => 'form-control', 'placeholder' =>'Enter Kilowatt'])); ?>

</div>

<div>
    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>Electricity Technology</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>