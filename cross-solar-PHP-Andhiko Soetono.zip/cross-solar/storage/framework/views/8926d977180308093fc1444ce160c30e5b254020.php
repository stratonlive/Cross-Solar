<?php $__env->startSection('content'); ?>
<h1>Panels List</h1>

   <?php if(count($panels)>0): ?>
   <?php $__currentLoopData = $panels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="list-group">
    <li class="list-group-item">Panel ID : <?php echo e($panel->id); ?></li>
    <li class="list-group-item">Serial: <?php echo e($panel->serial); ?></li>
    <li class="list-group-item">Latitude: <?php echo e($panel->latitude); ?></li>
    <li class="list-group-item">Longitude: <?php echo e($panel->longitude); ?></li>
</ul> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>Solar Technology</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>