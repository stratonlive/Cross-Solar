<?php $__env->startSection('content'); ?>
<h1>Daily Kwh Reports</h1>

 <?php if(count($chart)>0): ?>
   <?php $__currentLoopData = $chart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="list-group">
    <li class="list-group-item"> <a class="button" href="charts/<?php echo e($panel->panel_id); ?>">Panel ID : <?php echo e($panel->panel_id); ?></a></li>
    <li class="list-group-item">Hour : <?php echo e(date('M j, Y H:i', strtotime($panel->hour))); ?></li>
    <li class="list-group-item">Kwh : <?php echo e($panel->total); ?> Kwh</li>
    <li class="list-group-item">Min Kwh : <?php echo e($panel->min); ?> Kwh</li>
    <li class="list-group-item">Max Kwh : <?php echo e($panel->max); ?> Kwh</li>
    <li class="list-group-item">Average Kwh : <?php echo e($panel->average); ?> Kwh</li>
</ul> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>Electricity</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>