<?php $__env->startSection('sidebar'); ?>
<div class="sidebar">
    <h3>Latest News</h3>
    
</div>
<?php echo $__env->yieldSection(); ?>