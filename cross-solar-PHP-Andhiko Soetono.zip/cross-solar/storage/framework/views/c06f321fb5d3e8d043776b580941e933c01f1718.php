<?php $__env->startSection('content'); ?>
<h1>Daily Panel Kwh Reports</h1>

 <?php if(count($reports)>0): ?>
   <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $watts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="list-group">
    <li class="list-group-item">Panel ID : <?php echo e($watts->panel_id); ?></a></li>
    <li class="list-group-item">Hour : <?php echo e(date('M j, Y H:i', strtotime($watts->hour))); ?></li>
    <li class="list-group-item">Kwh : <?php echo e($watts->total); ?> Kwh</li>
</ul> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>Electricity</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>