<?php $__env->startSection('content'); ?>
<h1>Kwh Chart Reports</h1>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable(      
        [
        ['Date and Time', 'Total KWh'],
        <?php $__currentLoopData = $panel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>['<?php echo e($panels->hour); ?>','<?php echo e($panels->total); ?>'],
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        var options = {
          chart: {
            title: 'Panel Daily Performance',
            subtitle: 'Total KWh Each Day',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
    
   <div id="barchart_material" style="width: 600px; height: 400px;"></div>
   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>Electricity</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>