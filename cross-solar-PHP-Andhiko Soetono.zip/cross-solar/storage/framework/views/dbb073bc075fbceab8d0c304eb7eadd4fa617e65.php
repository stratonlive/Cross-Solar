<?php $__env->startSection('content'); ?>
<h1>Input Panel</h1>
<?php echo Form::open(['url' => 'input/submit']); ?>

<div class="form-group">
    <?php echo e(Form::label('serial', 'serial')); ?>

    <?php echo e(Form::text('serial', '', ['class' => 'form-control', 'placeholder' =>'Enter Serial'] )); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('latitude', 'latitude')); ?>

    <?php echo e(Form::text('latitude', '', ['class' => 'form-control', 'placeholder' =>'Enter Latitude'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('longitude', 'longitude')); ?>

    <?php echo e(Form::text('longitude', '', ['class' => 'form-control', 'placeholder' =>'Enter Longitude'])); ?>

</div>

<div>
    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>The Solar Technology</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>