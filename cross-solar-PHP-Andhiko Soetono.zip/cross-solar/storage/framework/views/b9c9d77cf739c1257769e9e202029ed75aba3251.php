<?php $__env->startSection('content'); ?>
<h1>About</h1>
<p>
    We are Energy Clean Power Plant.
    
</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
   ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <p>This is the history of our Company</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>